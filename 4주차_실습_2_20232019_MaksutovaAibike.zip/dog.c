#include <stdio.h>

void dog() {
    printf("Dog says: Woof!\n");
}
