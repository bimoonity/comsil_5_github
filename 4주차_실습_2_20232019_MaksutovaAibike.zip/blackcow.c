#include <stdio.h>

void blackcow() {
    printf("Black cow says: Moo!\n");
}
