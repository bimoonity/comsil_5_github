#include <stdio.h>

void turtle() {
    printf("Turtle says: ...\n");
}
