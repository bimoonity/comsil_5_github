#include <stdio.h>

extern void dog();
extern void blackcow();
extern void turtle();

int main() {
    printf("Starting animal sounds...\n");
    dog();
    blackcow();
    turtle();
    return 0;
}
