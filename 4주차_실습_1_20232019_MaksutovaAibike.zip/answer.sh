#!/bin/bash

if [ $# -eq 0 ]; then
    name=$(basename "$0")
    echo "Usage: $name searchfor [... searchfor]"
    echo "(You didn't tell me what you want to search for.)"
    exit 1
fi

pattern=$(IFS="|"; echo "$*")

egrep -i "($pattern)" mydata.txt | awk -f display.awk
